import argparse
import json
parser = argparse.ArgumentParser(description="your script description") 
parser.add_argument('-d', action='store', dest='dist', default=None, help="The input DFA file, in JSON format.", required=True)  
parser.add_argument('-v', action='store_true',dest='file', help="The input DFA file, in JSON format.", required=False)    
args = parser.parse_args()
if (args.file): 
     with open(args.dist) as j_data:
        data=json.load(j_data)
     
     print('--------------------Begin definition------------------')
     print json.dumps(data, sort_keys=True, indent=2)
     print('--------------------End definition------------------')

     while(True):
         l=len(data['transition'])
         cu_state=data['start_state']
         b=data['transition']
         last=data['final_states']
         lis=[]
 	 flag=1
         w=input('String:')
         q=str(w)

         def spot(q,w):
            for i in range(l):
               if b[i]['current_state'] == q:
                  if b[i]['next_symbol'] == w:
                     cu_state= b[i]['new_state']
                     print(' Current State: '+q+' Symbol: '+w+' ---->New State: '+cu_state)
                     lis.append(cu_state)
                     return cu_state
	 
       

         for i in q:
            if(i!="0" and i!="1") : 
               print('Invalid alphabet:'+ i)
	       flag=0
               break
            cu_state=spot(cu_state,i)

         if (lis[-1] == last and flag == 1):
            print( ' String: '+ q +'----->' + ' accepted ')  
         else:
            print( ' String: '+ q +' -----> ' + ' not accepted ')
	      
 		
else:
 with open(args.dist) as j_data:
   data=json.load(j_data)
  
	
   l=len(data['transition'])
   cu_state=data['start_state']
   b=data['transition']
   last=data['final_states']
   print('--------------------Begin definition------------------')
   
   print json.dumps(data, sort_keys=True, indent=2)
   print('--------------------End definition------------------')

   def spot(q,w):
     for i in range(l):
        if b[i]['current_state'] == q:
           if b[i]['next_symbol'] == w:
                cu_state= b[i]['new_state']
                lis.append(cu_state)
	        #print(lis[0])
                return cu_state

   while(True):
      lis=[]
      flag=1
      w=input('String:')
      q=str(w)
 

      for i in q:
          if(i!="0" and i!="1") : 
               print('Invalid alphabet:'+ i)
	       flag=0
               break
          cu_state=spot(cu_state,i)
 
  
      if (lis[-1] == last and flag==1):
         print( 'String:'+q+'----->'+ ' accepted')
      else:
         print( 'String:'+q+'----->'+ 'not accepted')

