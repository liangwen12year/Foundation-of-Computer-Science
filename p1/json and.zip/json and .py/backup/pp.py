x=int(input('enter number of states:'))
st=[(input('Enter states:')) for i in range(0,x)]
y=int(input('enter number of keys:'))
ky=[input('Enter keys:') for i in range(0,y)]
last=(input('specify the final stage:'))
k=[0 for i in range(len(st))]
for i in range (len(st)):
  k[i]=[0 for j in range(len(ky))]
  for j in range(len(ky)):
    k[i][j]= input('from ' + st[i] + 'if '+ ky[j]+ 'go: ')
def spot(q,w):
  lis.append(k[st.index(q)][ky.index(w)])
  return k[st.index(q)][ky.index(w)]
while True:
 lis=[]
 strt=st[0]
 w=input('String to check: ')
 for i in w:
   strt=spot(strt,i)
 if lis[-1] == last:
    print('String accepted by grammer ('+ st[0]+'..'.join(lis)+')')
 else:
    print('String not accepted by grammer')

