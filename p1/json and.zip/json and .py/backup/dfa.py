import json

with open('dfa.json') as j_data:
   data=json.load(j_data)

   l=len(data['transition'])
   cu_state=data['start_state']
   b=data['transition']
   last=data['final_states']
lis=[]
w=input('String to check ')

def spot(q,w):
    for i in range(l):
        if b[i]['current_state'] == q:
           if b[i]['next_symbol'] == w:
                cu_state= b[i]['new_state']
                lis.append(cu_state)
                return cu_state

for i in w:
    cu_state=spot(cu_state,i)
if lis[-1] == last:
    print('String accepted by grammer ('+ data['start_state']+'->'.join(lis)+')')
else:
    print('String not accepted by grammer')

