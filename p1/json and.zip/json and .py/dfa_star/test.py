import argparse
import json
parser = argparse.ArgumentParser(description="your script description") 
parser.add_argument('-d', action='store', dest='dist', default=None, help="The input DFA file, in JSON format.", required=True)  
parser.add_argument('-v', action='store_true',dest='file', help="The input DFA file, in JSON format.", required=False)    
args = parser.parse_args()
if (args.file): 
     with open(args.dist) as j_data:
        data=json.load(j_data)
     
     print('--------------------Begin definition------------------')
     print json.dumps(data, sort_keys=True, indent=2)
     print('--------------------End definition------------------')

     while(True):
         l=len(data['transition'])
         cu_state=data['start_state']
         b=data['transition']
         last=data['final_states']
         lis=[]
 	 flag=1
         w=input('String:')
         q=str(w)
	 if(q[0]!="a"):
	      print(' Current State: '+cu_state+' Symbol: '+q[0]+' ---->New State: '+'q5')
	      for i in q[1] to q[-1]:
                   print(' Current State: '+'q5'+' Symbol: '+i+' ---->New State: '+'q5')
