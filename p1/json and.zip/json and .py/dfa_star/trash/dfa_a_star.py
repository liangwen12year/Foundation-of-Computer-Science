import argparse
import json
parser = argparse.ArgumentParser(description="your script description") 
parser.add_argument('-d', action='store', dest='file', default=None, help="The input DFA file, in JSON format.", required=True)         
args = parser.parse_args()
print(args.file)  

with open(args.file) as j_data:
   data=json.load(j_data)

   l=len(data['transition'])
   cu_state=data['start_state']
   b=data['transition']
   last=data['final_states']
while(True):
 lis=[]
 
 w=input('String:')

 def spot(q,w):
     for i in range(l):
        if b[i]['current_state'] == q:
           if b[i]['next_symbol'] == w:
                cu_state= b[i]['new_state']
                lis.append(cu_state)
                return cu_state

 for i in w:
    if(w[0]!=a)
    cu_state=spot(cu_state,i)
 if (lis[-1] == last):
   print( 'String:'+w+'----->'+ ' accepted')
 else:
    print( 'String:'+w+'----->'+ 'not accepted')

